import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { shouldProxyRemoteFiles } from "@/lib/ai/remote-agent-proxy";

/**
 * 回归测试：远端文件代理在生产默认关闭。
 *
 * 背景：代理使用固定的远端账号凭据读取文件。若仅凭 REMOTE_AGENT_* 配置
 * 就启用，会让本地鉴权失败的请求借固定账号绕过归属校验，构成越权风险。
 * 必须显式设置 REMOTE_AGENT_FILE_PROXY=1 才启用（本地验证专用）。
 */
describe("shouldProxyRemoteFiles", () => {
  const originalEnv = { ...process.env };

  beforeEach(() => {
    process.env.REMOTE_AGENT_EMAIL = "remote@example.com";
    process.env.REMOTE_AGENT_PASSWORD = "secret";
    process.env.REMOTE_AGENT_WORKSPACE_ID = "ws-1";
    delete process.env.REMOTE_AGENT_FILE_PROXY;
  });

  afterEach(() => {
    process.env = { ...originalEnv };
  });

  it("远端 Agent 已配置但未显式开启文件代理时，必须关闭", () => {
    expect(shouldProxyRemoteFiles()).toBe(false);
  });

  it("仅当显式设置 REMOTE_AGENT_FILE_PROXY=1 时才开启", () => {
    process.env.REMOTE_AGENT_FILE_PROXY = "1";
    expect(shouldProxyRemoteFiles()).toBe(true);
  });

  it("远端 Agent 未配置时，即使有开关也不开启", () => {
    delete process.env.REMOTE_AGENT_WORKSPACE_ID;
    process.env.REMOTE_AGENT_FILE_PROXY = "1";
    expect(shouldProxyRemoteFiles()).toBe(false);
  });
});
