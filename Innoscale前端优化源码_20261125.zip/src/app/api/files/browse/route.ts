import { NextRequest, NextResponse } from "next/server";
import { listDirectory } from "@/lib/files/filesystem";
import { requireWorkspaceProvisioningPathsAccess } from "@/lib/auth/ownership";
import { jsonException, requiredSearchParam } from "@/lib/api-errors";
import { proxyRemoteFileRequest, shouldProxyRemoteFiles } from "@/lib/ai/remote-agent-proxy";

export async function GET(request: NextRequest) {
  try {
    const dirPath = requiredSearchParam(request, "path", "Missing path parameter");
    if (dirPath instanceof NextResponse) {
      return dirPath;
    }

    const access = await requireWorkspaceProvisioningPathsAccess(request, [
      dirPath,
    ]);
    // 未认证（401）绝不走远端固定账号代理，避免越权。
    if (access instanceof NextResponse && access.status === 401) {
      return access;
    }
    if (!(access instanceof NextResponse)) {
      try {
        const entries = await listDirectory(access.canonicalPaths[0]);
        return NextResponse.json(entries);
      } catch {
        // 本地目录不存在：远端 Agent 工作区目录回退
      }
    }

    if (shouldProxyRemoteFiles()) {
      // 用已规范化的本地路径作为远端兜底参数，避免原始 path 的不一致与穿越。
      const remotePath = access instanceof NextResponse ? dirPath : access.canonicalPaths[0];
      const remote = await proxyRemoteFileRequest("browse", remotePath);
      if (remote) return remote;
    }

    if (access instanceof NextResponse) return access;
    return jsonException(new Error("Directory not found"), "Failed to browse directory");
  } catch (error) {
    return jsonException(error, "Failed to browse directory");
  }
}
