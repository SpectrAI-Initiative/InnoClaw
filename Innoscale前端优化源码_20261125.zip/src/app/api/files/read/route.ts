import { NextRequest, NextResponse } from "next/server";
import { readFile } from "@/lib/files/filesystem";
import { requirePathAccess } from "@/lib/auth/ownership";
import { jsonException, requiredSearchParam } from "@/lib/api-errors";
import { proxyRemoteFileRequest, shouldProxyRemoteFiles } from "@/lib/ai/remote-agent-proxy";

export async function GET(request: NextRequest) {
  try {
    const filePath = requiredSearchParam(request, "path", "Missing path parameter");
    if (filePath instanceof NextResponse) {
      return filePath;
    }

    const access = await requirePathAccess(request, filePath);

    // 安全：未认证（401）必须原样返回，绝不能借远端固定账号越权读取。
    // 403（已认证但路径不在本地工作区）是远端 Agent 交付物的正常情形，
    // 允许在显式开启文件代理时走远端兜底；代理自身会再次校验归属与路径。
    if (access instanceof NextResponse && access.status === 401) {
      return access;
    }

    if (!(access instanceof NextResponse)) {
      try {
        const content = await readFile(filePath);
        return NextResponse.json({ content });
      } catch {
        // 本地没有该文件：远端 Agent 模式下再试远端工作区
      }
    }

    if (shouldProxyRemoteFiles()) {
      const remote = await proxyRemoteFileRequest("read", filePath);
      if (remote) return remote;
    }

    if (access instanceof NextResponse) return access;
    return jsonException(new Error("File not found"), "Failed to read file");
  } catch (error) {
    return jsonException(error, "Failed to read file");
  }
}
